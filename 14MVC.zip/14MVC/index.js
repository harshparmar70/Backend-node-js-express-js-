const express = require("express");
const mongoose = require("mongoose");
let insertEnquiry = require("./app/controllers/web/userEnquiryController");
require("dotenv").config()
const app = express();
app.use(express.json());

app.post("/api/enquiry-insert", insertEnquiry);
app.get("/api/enquiry-list", enqurylist)
app.delete("/api/enquiry-delete/:id", deleteEnquiry)
app.put("/api/enquiry-update/:id", updateEnquiry)

mongoose.connect(process.env.mongo_url)
    .then(() => {
        console.log("Connected to MongoDB");
        app.listen(process.env.PORT, () => {
            console.log(`Server running on port ${process.env.PORT}`);
        });
    })
    .catch((err) => {
        console.error("MongoDB connection error:", err);
    });